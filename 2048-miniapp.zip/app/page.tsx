"use client"

import { useEffect, useState } from "react"
import sdk from "@farcaster/frame-sdk"
import Game2048 from "@/components/Game2048"

export default function Home() {
  const [isSDKLoaded, setIsSDKLoaded] = useState(false)
  const [context, setContext] = useState<any>(null)
  const [sdkAvailable, setSdkAvailable] = useState(false)

  useEffect(() => {
    const load = async () => {
      try {
        console.log("[v0] Initializing Farcaster SDK...")

        // Initialize the Farcaster SDK
        const result = await sdk.actions.ready()
        console.log("[v0] SDK ready result:", result)

        // Get context from the frame
        const ctx = sdk.context
        console.log("[v0] Farcaster context:", ctx)

        setContext(ctx)
        setSdkAvailable(true)
      } catch (err) {
        console.log("[v0] Farcaster SDK not available (expected in preview):", err)
        // SDK not available - this is normal in v0 preview
        setSdkAvailable(false)
      } finally {
        setIsSDKLoaded(true)
      }
    }

    load()
  }, [])

  if (!isSDKLoaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#faf8ef]">
        <div className="text-center">
          <div className="mb-4 text-2xl font-bold text-[#776e65]">Loading 2048...</div>
          <div className="h-2 w-48 overflow-hidden rounded-full bg-[#cdc1b4]">
            <div className="h-full w-1/2 animate-pulse bg-[#edc22e]"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#faf8ef] p-4">
      <div className="mb-6 text-center">
        <h1 className="mb-2 text-5xl font-bold text-[#776e65]">2048</h1>
        <p className="text-sm text-[#776e65]">
          Join the tiles, get to <strong>2048!</strong>
        </p>
      </div>

      {!sdkAvailable && (
        <div className="mb-4 max-w-md rounded-lg bg-blue-50 px-4 py-3 text-sm text-blue-800">
          <p className="font-semibold">Preview Mode</p>
          <p className="mt-1">Farcaster features will be available after you deploy. The game works perfectly here!</p>
        </div>
      )}

      <Game2048 context={context} sdkAvailable={sdkAvailable} />

      {context?.user && (
        <div className="mt-4 text-center text-sm text-[#776e65]">Playing as @{context.user.username}</div>
      )}
    </main>
  )
}
