"use client"

import sdk from "@farcaster/frame-sdk"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface ShareButtonProps {
  score: number
  sdkAvailable: boolean
}

export default function ShareButton({ score, sdkAvailable }: ShareButtonProps) {
  const [isSharing, setIsSharing] = useState(false)

  const handleShare = async () => {
    setIsSharing(true)

    try {
      if (sdkAvailable) {
        // Use Farcaster SDK to compose cast
        await sdk.actions.composeCast({
          text: `I just scored ${score} points in 2048! 🎮\n\nCan you beat my score? Play now!`,
          embeds: [typeof window !== "undefined" ? window.location.href : ""],
        })
        console.log("[v0] Cast composed successfully")
      } else {
        // Fallback: copy to clipboard for preview
        const shareText = `I just scored ${score} points in 2048! 🎮 Can you beat my score?`

        if (typeof navigator !== "undefined" && navigator.clipboard) {
          await navigator.clipboard.writeText(shareText)
          alert("✅ Score copied to clipboard!\n\n(Farcaster sharing will work after deployment)")
        }
      }
    } catch (error) {
      console.error("[v0] Error sharing:", error)
      alert("Unable to share. Please try again.")
    } finally {
      setIsSharing(false)
    }
  }

  return (
    <Button
      onClick={handleShare}
      disabled={isSharing}
      className="bg-[#edc22e] text-white hover:bg-[#edcc61] disabled:opacity-50"
      title={sdkAvailable ? "Share on Farcaster" : "Copy score (Deploy for Farcaster sharing)"}
    >
      {isSharing ? "Sharing..." : "Share Score"}
    </Button>
  )
}
